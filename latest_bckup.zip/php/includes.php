<?php
session_start();
require_once __DIR__ . "/includes/settings.php";   // Settings for database connection, etc.
require_once __DIR__ . '/includes/tools.php';
require_once __DIR__ . '/includes/variables.php';
require_once __DIR__ . '/includes/functions.php';
