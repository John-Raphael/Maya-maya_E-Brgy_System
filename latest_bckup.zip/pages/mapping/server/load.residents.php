<?php
include '../../../php/includes.php';

$id = $form->input("osm_id");

$house = table("tbl_houses")->where("coordinates_id = $id")->load();

if(count($house) == 0){
    response(false,"House not found");
}

$houseDetails = $house[0];

$house_id = $houseDetails["id"];

$residents = table("tbl_resident")->where("house_id = $house_id")->load();

response(true,"",$residents);